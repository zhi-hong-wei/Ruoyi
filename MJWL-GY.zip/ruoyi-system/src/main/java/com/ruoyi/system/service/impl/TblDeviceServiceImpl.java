package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.TblDeviceMapper;
import com.ruoyi.system.domain.TblDevice;
import com.ruoyi.system.service.ITblDeviceService;
import com.ruoyi.common.core.text.Convert;

/**
 * 设备管理Service业务层处理
 * 
 * @author admin
 * @date 2020-10-18
 */
@Service
public class TblDeviceServiceImpl implements ITblDeviceService 
{
    @Autowired
    private TblDeviceMapper tblDeviceMapper;

    /**
     * 查询设备管理
     * 
     * @param id 设备管理ID
     * @return 设备管理
     */
    @Override
    public TblDevice selectTblDeviceById(Long id)
    {
        return tblDeviceMapper.selectTblDeviceById(id);
    }

    /**
     * 查询设备管理列表
     * 
     * @param tblDevice 设备管理
     * @return 设备管理
     */
    @Override
    public List<TblDevice> selectTblDeviceList(TblDevice tblDevice)
    {
        return tblDeviceMapper.selectTblDeviceList(tblDevice);
    }

    /**
     * 新增设备管理
     * 
     * @param tblDevice 设备管理
     * @return 结果
     */
    @Override
    public int insertTblDevice(TblDevice tblDevice)
    {
        tblDevice.setCreateTime(DateUtils.getNowDate());
        return tblDeviceMapper.insertTblDevice(tblDevice);
    }

    /**
     * 修改设备管理
     * 
     * @param tblDevice 设备管理
     * @return 结果
     */
    @Override
    public int updateTblDevice(TblDevice tblDevice)
    {
        tblDevice.setUpdateTime(DateUtils.getNowDate());
        return tblDeviceMapper.updateTblDevice(tblDevice);
    }

    /**
     * 删除设备管理对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteTblDeviceByIds(String ids)
    {
        return tblDeviceMapper.deleteTblDeviceByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除设备管理信息
     * 
     * @param id 设备管理ID
     * @return 结果
     */
    @Override
    public int deleteTblDeviceById(Long id)
    {
        return tblDeviceMapper.deleteTblDeviceById(id);
    }
}
