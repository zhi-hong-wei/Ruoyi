package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.TblDevice;

/**
 * 设备管理Mapper接口
 * 
 * @author admin
 * @date 2020-10-18
 */
public interface TblDeviceMapper 
{
    /**
     * 查询设备管理
     * 
     * @param id 设备管理ID
     * @return 设备管理
     */
    public TblDevice selectTblDeviceById(Long id);

    /**
     * 查询设备管理列表
     * 
     * @param tblDevice 设备管理
     * @return 设备管理集合
     */
    public List<TblDevice> selectTblDeviceList(TblDevice tblDevice);

    /**
     * 新增设备管理
     * 
     * @param tblDevice 设备管理
     * @return 结果
     */
    public int insertTblDevice(TblDevice tblDevice);

    /**
     * 修改设备管理
     * 
     * @param tblDevice 设备管理
     * @return 结果
     */
    public int updateTblDevice(TblDevice tblDevice);

    /**
     * 删除设备管理
     * 
     * @param id 设备管理ID
     * @return 结果
     */
    public int deleteTblDeviceById(Long id);

    /**
     * 批量删除设备管理
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteTblDeviceByIds(String[] ids);
}
