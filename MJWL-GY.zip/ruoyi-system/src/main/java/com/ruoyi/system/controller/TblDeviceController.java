package com.ruoyi.system.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.TblDevice;
import com.ruoyi.system.service.ITblDeviceService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 设备管理Controller
 * 
 * @author admin
 * @date 2020-10-18
 */
@Controller
@RequestMapping("/system/device")
public class TblDeviceController extends BaseController
{
    private String prefix = "system/device";

    @Autowired
    private ITblDeviceService tblDeviceService;

    @RequiresPermissions("system:device:view")
    @GetMapping()
    public String device()
    {
        return prefix + "/device";
    }

    /**
     * 查询设备管理列表
     */
    @RequiresPermissions("system:device:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(TblDevice tblDevice)
    {
        startPage();
        List<TblDevice> list = tblDeviceService.selectTblDeviceList(tblDevice);
        return getDataTable(list);
    }

    /**
     * 导出设备管理列表
     */
    @RequiresPermissions("system:device:export")
    @Log(title = "设备管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(TblDevice tblDevice)
    {
        List<TblDevice> list = tblDeviceService.selectTblDeviceList(tblDevice);
        ExcelUtil<TblDevice> util = new ExcelUtil<TblDevice>(TblDevice.class);
        return util.exportExcel(list, "device");
    }

    /**
     * 新增设备管理
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存设备管理
     */
    @RequiresPermissions("system:device:add")
    @Log(title = "设备管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(TblDevice tblDevice)
    {
        return toAjax(tblDeviceService.insertTblDevice(tblDevice));
    }

    /**
     * 修改设备管理
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        TblDevice tblDevice = tblDeviceService.selectTblDeviceById(id);
        mmap.put("tblDevice", tblDevice);
        return prefix + "/edit";
    }

    /**
     * 修改保存设备管理
     */
    @RequiresPermissions("system:device:edit")
    @Log(title = "设备管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(TblDevice tblDevice)
    {
        return toAjax(tblDeviceService.updateTblDevice(tblDevice));
    }

    /**
     * 删除设备管理
     */
    @RequiresPermissions("system:device:remove")
    @Log(title = "设备管理", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(tblDeviceService.deleteTblDeviceByIds(ids));
    }
}
